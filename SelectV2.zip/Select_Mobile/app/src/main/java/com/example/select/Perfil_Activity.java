package com.example.select;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Perfil_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil);


        Button btnPerfilAddEndereco = findViewById(R.id.btnPerfilAddEndereco);
        btnPerfilAddEndereco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Perfil_Activity.this, AdicionarEndereco_Activity.class);
                startActivity(i);
            }
        });


        Button btnPerfilAlterarSenha = findViewById(R.id.btnPerfilAlterarSenha);
        btnPerfilAlterarSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Perfil_Activity.this, AlterarSenha_Activity.class);
                startActivity(i);
            }
        });


        Button btnPerfilSalvar = findViewById(R.id.btnPerfilSalvar);
        btnPerfilSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Perfil_Activity.this, Main_Activity.class);
                startActivity(i);
            }
        });


        Button btnPerfilCancelar = findViewById(R.id.btnPerfilCancelar);
        btnPerfilCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Perfil_Activity.this, Main_Activity.class);
            }
        });

    }
}