package com.example.select;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Cadastro_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);


        Button btnCadastroSalvar = findViewById(R.id.btnCadastroSalvar);
        btnCadastroSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Cadastro_Activity.this, Main_Activity.class);
                startActivity(i);
            }
        });

        Button btnCadastroCancelar = findViewById(R.id.btnCadastroCancelar);
        btnCadastroCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Cadastro_Activity.this, Login_Activity.class);
                startActivity(i);
            }
        });

    }
}