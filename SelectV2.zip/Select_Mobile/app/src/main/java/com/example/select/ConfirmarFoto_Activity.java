package com.example.select;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmarFoto_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmar_foto);


        Button btnFotoEnviar = findViewById(R.id.btnFotoEnviar);
        btnFotoEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ConfirmarFoto_Activity.this, SolicitarRetirada_Activity.class);
                startActivity(i);
            }
        });


        Button btnFotoCancelar = findViewById(R.id.btnFotoCancelar);
        btnFotoCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ConfirmarFoto_Activity.this, SolicitarRetirada_Activity.class);
                startActivity(i);
            }
        });

    }


}
